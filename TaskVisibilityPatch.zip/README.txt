Vtiger CRM Task Visibility Patch
================================

Description:
This patch fixes the issue where "Task" records in the Calendar module were not visible to lower-level users, unlike "Events".

Files Included:
- ListView.php (Modified)
- README.txt (This file)

Changes Details:
File: modules/Calendar/models/ListView.php
Lines Modified: ~309-311

Change:
Commented out the code block that filtered out Tasks based on sharing permissions:

//            if(!$currentUser->isAdminUser() && $rawData['activitytype'] == 'Task' && isToDoPermittedBySharing($recordId) == 'no') {
//                              $recordsToUnset[] = $recordId;
//                      }

Installation:
1. Backup your existing `modules/Calendar/models/ListView.php`.
2. Replace it with the `ListView.php` from this zip file.

