<?php
class CalendarFixHandler extends VTEventHandler {

    function handleEvent($eventName, $entityData) {
        if ($eventName === 'vtiger.entity.beforesave') {
            $moduleName = $entityData->getModuleName();   
            $entityDelta = new VTEntityDelta();       
            if ($moduleName === 'Events') {
            
                $newActivityType = $entityData->get('activitytype');
                $recordId = $entityData->getId();
                 // Only if record already exists (update case)
                if ($recordId && $newActivityType === 'Task') {
                    global $adb;
                    $sql = "SELECT activitytype FROM vtiger_activity WHERE activityid=?";
                    $res = $adb->pquery($sql, [$recordId]);
                    if ($adb->num_rows($res) > 0) {
                        $oldActivityType = $adb->query_result($res, 0, 'activitytype');
                        // Reset to old value         
                        if (!empty($oldActivityType)) {
                            $entityData->set('activitytype', $oldActivityType);
                        }
                    }
                }
                
                $changedFields = $entityData->getData()->changed ?? [];
                if (in_array('cf_1023', $changedFields)) {
                    $cf1023 = $entityData->get('cf_1023');
                    if (!empty($cf1023)) {
                        $entityData->set('cf_1025', $cf1023);
                    }
                }
            }
        }
    }
}
?>
