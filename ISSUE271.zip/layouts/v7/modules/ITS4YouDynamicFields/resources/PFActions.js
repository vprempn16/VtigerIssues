/*********************************************************************************
 * The content of this file is subject to the Dynamic Fields 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 ********************************************************************************/

/** @var ITS4YouDynamicFields_PFActions_Js */
Vtiger.Class('ITS4YouDynamicFields_PFActions_Js', {
    actionData: false,
    instance: false,
    getInstance: function () {
        if (!this.instance) {
            this.instance = new ITS4YouDynamicFields_PFActions_Js()
        }

        return this.instance;
    },

    getInstanceByModuleName: function (moduleName) {
    },
}, {
    firstLoad: true,
    viewType: false,
    forModule: false,
    forView: false,
    forRecord: false,
    modulefields: false,
    nummodulefields: 0,
    formElement: false,
    control_man_file: [],
    debug: false,
    cf: false,
    dfContainer: false,
    isreadonlyfield: [],

    run: function (recordId, actiondata, container) {
        let thisInstance = this;
        thisInstance.viewType = app.view();

        if (actiondata.data) {

            if ('undefined' !== typeof actiondata.data.action) {

                if ('setDynamicFields' === actiondata.data.action) {
                    ITS4YouDynamicFields_PFActions_Js.actionData = actiondata;

                    thisInstance.actionData = actiondata;
                    thisInstance.forModule = actiondata.data.for_module;
                    thisInstance.forView = actiondata.data.for_view;
                    thisInstance.forRecord = actiondata.data.for_record;
                    thisInstance.setContainer(container);

                    if('ListEdit' === thisInstance.forView) {
                        thisInstance.registerListEdit();
                    } else {
                        thisInstance.HideOrShowFields(thisInstance, actiondata.data.fields, 0, []);
                    }

                    thisInstance.firstLoad = false;
                }
            }
        }
    },
    isAddressBlockField: function (element) {
        return element.parents('[data-block="LBL_ADDRESS_INFORMATION"]').length;
    },
    getForModule: function () {
        return this.forModule;
    },
    setForModule: function (value) {
        this.forModule = value;
    },
    getSummaryFieldId: function (fieldName) {
        return this.getForModule() + '_detailSummary_fieldName_' + fieldName;
    },
    getSummaryField: function (fieldName) {
        let self = this;

        return $("#" + self.getSummaryFieldId(fieldName));
    },
    isEditView: function () {
        return 'Edit' === this.forView || 'relatedEdit' === this.forView;
    },
    setHeaderForm: function (element) {
        this.headerForm = element;
    },
    getHeaderForm: function () {
        if (!this.headerForm) {
            this.setHeaderForm($('#headerForm'));
        }

        return this.headerForm;
    },
    getHeaderField: function (fieldName) {
        return this.getHeaderForm().find('.value.' + fieldName);
    },
    hideHeaderField: function (fieldName) {
        this.getHeaderField(fieldName).parent().hide();
    },
    showHeaderField: function (fieldName) {
        let fieldElement = this.getHeaderField(fieldName),
            fieldParent = fieldElement.parent();

        fieldParent.show();
    },
    readonlyHeaderField: function (fieldName, isReadonly) {
        let fieldElement = this.getHeaderField(fieldName),
            actionElement = fieldElement.parent().find('.action');

        actionElement.removeClass('hide');

        if (isReadonly) {
            actionElement.addClass('hide');
        }
    },
    hideImageName: function (fieldName) {
        if ('imagename' === fieldName) {
            jQuery('#imageContainer').closest('tr').find('td').hide();
        }
    },
    HideOrShowFields: function (thisInstance, response, nummodulefields, modulefields) {
        let result = response['success'],
            module = thisInstance.forModule,
            is_modified = false,
            fieldtype;

        if (result) {
            let new_fields = [],
                numhidefields = response['numhidefields'];

            thisInstance.modifyBlocksContent(thisInstance, 'start');
            thisInstance.modulefields = response['fields'];
            thisInstance.nummodulefields = response['numfields'];

            if (numhidefields > 0) {
                let hidefields = response['hidefields'];

                for (let i = 0; i < numhidefields; i++) {
                    let fieldName = hidefields[i];

                    thisInstance.removeReadonlyElement(fieldName);

                    if ('Detail' === thisInstance.forView) {
                        let fieldElement = thisInstance.getFieldElement(fieldName);

                        if (fieldElement.length > 0) {
                            this.modifyTRLine(fieldElement, 'hide');
                        }

                        thisInstance.hideImageName(fieldName);			
                        thisInstance.hideHeaderField(fieldName);
                    } else {
                        let fieldElement = thisInstance.getFieldElementByName(fieldName);

                        if (fieldElement.length > 0) {
                            this.disableField(fieldElement, true);
                            this.modifyTRLine(fieldElement, "hide");
                        }
                    }
                }
            }

            let numshowreadonlyfields = response['numshowreadonlyfields'],
                numhideinblock = response['numhideinblock'],
                numshowfields = response['numshowfields'];

            if (numshowfields > 0) {
                let showfields = response['showfields'];

                for (let i = 0; i < numshowfields; i++) {
                    let fieldName = showfields[i],
                        fieldElement = this.getFieldElementByName(fieldName);

                    this.disableField(fieldElement, false);
                    is_modified = this.modifyTRLine(fieldElement, 'show');

                    if (is_modified) {
                        fieldtype = fieldElement.attr('type');

                        if (typeof fieldtype == 'undefined') {
                            fieldtype = "";
                        }

                        if ('file' !== fieldtype) {

                            if (numshowreadonlyfields > 0 || numhideinblock > 0) {

                                if (-1 === jQuery.inArray(fieldName, response['showreadonlyfields'])) {
                                    new_fields.push(fieldName);
                                }
                            } else {
                                new_fields.push(fieldName);
                            }
                        }
                    }

                    if (-1 === jQuery.inArray(fieldName, response['showmanfields'])) {
                        let fieldElement = thisInstance.getFieldElementByName(fieldName),
                            controlMan = fieldElement.closest('tr').find('.redColor');

                        if (controlMan) {

                            if (controlMan.length > 0) {
                               is_modified = thisInstance.modifyValidationToElement(fieldName, 'hide');
                            }
                        }
                    }

                    thisInstance.showHeaderField(fieldName);
                }
            }
            if (numshowreadonlyfields > 0) {
                let showreadonlyfields = response['showreadonlyfields'];

                for (let i = 0; i < numshowreadonlyfields; i++) {
                    let fieldName = showreadonlyfields[i],
                        fieldElement = this.getFieldElementByName(fieldName);

                    this.disableField(fieldElement, false);
                   this.readonlyField(showreadonlyfields[i], fieldElement, true);
                    this.readonlyHeaderField(fieldName, true);
                }
            }
            let numhidereadonlyfields = response['numhidereadonlyfields'];

            if (numhidereadonlyfields > 0) {
                let hidereadonlyfields = response['hidereadonlyfields'];

                for (let i = 0; i < numhidereadonlyfields; i++) {
                    let fieldName = hidereadonlyfields[i],
                        fieldElement = this.getFieldElementByName(fieldName);

                    this.readonlyField(hidereadonlyfields[i], fieldElement, false);
                    this.readonlyHeaderField(fieldName, false);
                }
            }

            if (thisInstance.isEditView()) {
                let numshowmanfields = response['numshowmanfields'];

                if (numshowmanfields > 0) {
                    let showmanfields = response['showmanfields'];

                    for (let i = 0; i < numshowmanfields; i++) {
                        is_modified = thisInstance.modifyValidationToElement(showmanfields[i], 'show');

                        if (is_modified) {
                            let fieldElement = this.getFieldElementByName(showmanfields[i]);
                            this.disableField(fieldElement, false);
                            this.modifyTRLine(fieldElement, 'show');

                            if (numhideinblock > 0) {

                                if (-1 === jQuery.inArray(showmanfields[i], response['hideinblock'])) {
                                    new_fields.push(showmanfields[i]);
                                }
                            } else {
                                new_fields.push(showmanfields[i]);
                            }
                        }
                    }
                }
                let numhidemanfields = response['numhidemanfields'];

                if (numhidemanfields > 0) {
                    let hidemanfields = response['hidemanfields'];

                    for (let i = 0; i < numhidemanfields; i++) {
                        is_modified = thisInstance.modifyValidationToElement(hidemanfields[i], 'hide');
                    }
                }
            }
            let numshowinpopup = response['numshowinpopup'];
            let popup_fields = [];

            if (!thisInstance.isEditView()) {
                popup_fields = new_fields;
            }

            if (numshowinpopup > 0) {
                let showinpopup = response['showinpopup'];

                for (let i = 0; i < numshowinpopup; i++) {

                    if (-1 === jQuery.inArray(showinpopup[i], popup_fields) && -1 === jQuery.inArray(showinpopup[i], response['showreadonlyfields'])) {
                        popup_fields.push(showinpopup[i]);
                    }
                }
            }

            if (response['hideinvblock'] !== '') {
                let totalProductCount = jQuery('input[name="total"]'),
                    invElement;

                if (totalProductCount.length > 0) {
                    invElement = totalProductCount.next('div[name="editContent"]');
                } else {
                    invElement = jQuery(".details.block");
                }

                if (response['hideinvblock'] === '1') {
                    invElement.addClass('hide');
                } else if (response['hideinvblock'] === '0') {
                    invElement.removeClass('hide');
                }
            }

            if (popup_fields.length > 0 && !thisInstance.firstLoad) {
                thisInstance.createPopup(popup_fields, response);
            }
        }

        thisInstance.modifyBlocksContent(thisInstance, 'end');
    },
    getFieldBlockContainers: function () {
        return $('.fieldBlockContainer').filter(function () {
            if ($(this).is('.duplicationMessageContainer')) {
                return false;
            }

            return true;
        });
    },
    getBlocks: function () {
        return $('.block').filter(function () {
            let blockId = jQuery(this).data('blockid');

            if ('undefined' != typeof blockId) {
                return true;
            }

            return false;
        });
    },
    modifyBlocksContent: function (thisInstance, type) {
        this.getFieldBlockContainers().each(function () {
            thisInstance.modifyBlockContent(this, type);
        });

        this.getBlocks().each(function () {
            thisInstance.modifyBlockContent(this, type);
        });
    },
    modifyValidationToElement: function (fieldName, type) {
        let self = this,
            fieldElement = self.getFieldElementByName(fieldName),
            is_modified = false;

        if (fieldElement.length > 0) {
            let tdFieldValue = fieldElement.parents('td'),
                tdFieldLabel = tdFieldValue.prev('td');

            if ('hide' === type) {
                tdFieldLabel.find('.redColor').hide();
                self.addValidationToElement(fieldName, fieldElement, false);

            } else if ('show' === type) {
                let RedSpan = tdFieldLabel.find('.redColor');

                if (RedSpan.length > 0) {

                    if (RedSpan.is(':hidden')) {
                        is_modified = true;
                        RedSpan.show();
                    }
                } else {
                    tdFieldLabel.append(' <span class="redColor">*</span>');
                    is_modified = true;
                }

                self.addValidationToElement(fieldName, fieldElement, true);
                self.readonlyField(fieldName, fieldElement, false);
            }
        }

        return is_modified;
    },
    filterHiddenTdElements: function (tdElements) {
        const self = this;

        return tdElements.filter(function () {
            const currentElement = jQuery(this);

            if (self.isAddressBlockField(currentElement)) {
                if (0 === parseInt(currentElement.css('opacity')) ||
                    currentElement.is('[name="copyAddress"], [name="copyHeader1"], [name="copyAddress1"], [name="copyHeader2"], [name="copyAddress2"]') ||
                    currentElement.is(':empty')
                ) {
                    return true;
                }
            }

            return currentElement.is(':hidden');
        })
    },
    getTdElements: function (blockElement) {
        return jQuery(blockElement).find('tbody > tr > td');
    },
    showBlock: function (blockElement) {
        blockElement.show();
        blockElement.next('br').show();
    },
    hideBlock: function (blockElement) {
        blockElement.hide();
        blockElement.next('br').hide();
    },
    isBlockHidden: function (blockElement) {
        let self = this,
            is_hidden = false;

        if ('Detail' === self.forView) {
            jQuery(blockElement).find('.blockToggle:visible').each(function () {
                let hidden_type = jQuery(blockElement).data('mode');

                if ('hide' === hidden_type) {
                    is_hidden = true;
                }
            })
        }

        if (!jQuery(blockElement).is(':visible')) {
            is_hidden = true;
        }

        return is_hidden;
    },
    isBlockBlank: function (blockElement) {
        let is_blank = true;

        jQuery(blockElement).find('tbody > tr').find('td:visible').each(function () {
            let contentTD = jQuery(this).html();

            if ('' !== contentTD) {
                is_blank = false;
            }
        });

        return is_blank;
    },
    modifyBlockContent: function (blockElement, type) {
        const self = this,
            elementTable = jQuery(blockElement);

        if ('start' === type) {
            self.showBlock(elementTable);
            self.showCollapsed(elementTable);
        } else {
            let allTDElements = self.getTdElements(blockElement),
                hiddenTDElements = self.filterHiddenTdElements(allTDElements),
                allTD = allTDElements.length,
                hiddenTD = hiddenTDElements.length,
                is_two = allTD - hiddenTD;

            if (2 === is_two) {
                if (self.isBlockBlank(blockElement)) {
                    allTD = hiddenTD;
                }
            }

            if (allTD === hiddenTD) {
                if (!self.isBlockHidden(elementTable)) {
                    self.hideBlock(elementTable);
                }
            } else {
                self.showBlock(elementTable);
            }

            self.hideCollapsed(elementTable);
        }
    },
    showCollapsed: function (elementTable) {
        if ('none' === elementTable.find('.blockToggle[data-mode="show"]').css('display')) {
            elementTable.find('.blockData tbody').show();
        }
    },
    hideCollapsed: function (elementTable) {
        if ('none' === elementTable.find('.blockToggle[data-mode="show"]').css('display')) {
            elementTable.find('.blockData tbody').hide();
        }
    },
    disableField: function (fieldElement, disabled_value) {

        if (fieldElement.hasClass('nodisablefield') && disabled_value) {
            return;
        }
	fieldtype = fieldElement.attr('data-fieldtype');
	if( fieldtype != undefined && fieldtype == 'checkbox'){ //ISSUE271 diable check field
	        fieldElement.prop('disabled', disabled_value);
	}else{
       	 	fieldElement.prop('readonly', disabled_value);
	}
    },
    readonlyField: function (fieldName, fieldElement, disabled_value) {
        let self = this,
            fieldType = '',
            tdElement = fieldElement.parents('td');

        if (fieldElement.hasClass('noreadonlyfield') && disabled_value) {
            return;
        }

        if (fieldElement.is('.dateField')) {
            fieldType = 'date';
        } else if (fieldElement.is('select')) {
            if (fieldElement.hasClass('select2')) {
                this.disableField(fieldElement, disabled_value);
                app.showSelect2ElementView(fieldElement);
                fieldElement.attr('readonly', false);
            } else {
                fieldElement.attr('readonly', disabled_value).trigger("liszt:updated");
                fieldElement.attr('readonly', false);
            }
        } else {
            fieldType = fieldElement.data('fieldtype');

            if ('undefined' === typeof fieldType) {
                fieldType = fieldElement.attr('type');
            }

            if ('hidden' === fieldType) {
                if (fieldElement.is('.sourceField')) {
                    let controlElement = tdElement.find("[name='" + fieldName + "_display']");

                    if (controlElement.length > 0) {
                        fieldElement = controlElement;
                        fieldType = 'reference';
                    }
                }
            }

            if ('file' === fieldType) {
                let fileDeleteElements = tdElement.find('.fileDelete');

                if (disabled_value) {
                    fieldElement.hide();
                    fileDeleteElements.hide();
                } else {
                    fieldElement.show();
                    fileDeleteElements.show();
                }
            } else {
                let select2Element = jQuery("[name='" + fieldElement.attr("name") + "[]']");

                if (typeof select2Element != "undefined") {
                    if (select2Element.hasClass("select2")) {
                        this.disableField(select2Element, disabled_value);
                        app.showSelect2ElementView(select2Element);
                        select2Element.attr('readonly', false);
                    }
                }
            }
        }

        if (disabled_value) {
            self.setReadonlyField(fieldName);
        } else {
            self.unsetReadonlyField(fieldName);
        }

        self.updateReadonlyCustomElement(fieldName, fieldElement, fieldType, disabled_value);
        self.updateReadonlyFieldElement(fieldElement, !disabled_value);
    },
    isCKEditorField: function (fieldName) {
        return 'object' === typeof CKEDITOR.instances[fieldName];
    },
    updateReadonlyFieldElement: function (fieldElement, show = true) {
        const tdElement = fieldElement.parents('td'),
            action = tdElement.find('.action'),
            fieldName = fieldElement.attr('name');

        if (show) {
            tdElement.removeClass('readonlyDynamicFields');

            if (!this.isCKEditorField(fieldName)) {
                fieldElement.show();
            }

            fieldElement.prop('readonly', false);
            action.attr('style', '');
            action.removeClass('hide');
        } else {
            tdElement.addClass('readonlyDynamicFields');
            fieldElement.hide();
            fieldElement.prop('readonly', true);
            action.addClass('hide');
        }
    },
    getFieldElement: function (fieldName) {
        let self = this,
            fieldElement = self.getEditField(fieldName);

        if (!fieldElement.length) {
            fieldElement = self.getDetailField(fieldName);
        }

        if (!fieldElement.length) {
            fieldElement = self.getSummaryField(fieldName);
        }

        return fieldElement;
    },
    getEditFieldId: function(fieldName) {
        return this.getForModule() + '_editView_fieldName_' + fieldName
    },
    getCopyElement: function (fieldName, fieldElement) {
        const self = this,
            fieldType = self.getFieldType(fieldElement);

        if ('reference' === fieldType) {
            return fieldElement.parents('td').find("[name='" + fieldName + "_display']");
        }

        if(self.isCKEditorField(fieldName)) {
            return fieldElement.filter('textarea');
        }

        return fieldElement.filter(':visible');
    },
    createReadonlyElement: function (fieldName, fieldElement) {
        let self = this,
            readonlyElement = self.getReadonlyElement(fieldName),
            copyElement = self.getCopyElement(fieldName, fieldElement);
        if (!readonlyElement.length) {
            if(copyElement.length){  //ISSUE271
                    readonlyElement = copyElement.clone();
            }else{
                readonlyElement = fieldElement.clone();
            }      

    	    fieldType =  readonlyElement.attr('data-fieldtype');
  	    readonlyElement.attr('id', '');
            readonlyElement.attr('name', '');
            readonlyElement.addClass(self.getReadonlyClass(fieldName));
	    if(fieldType != undefined && fieldType == 'checkbox' ){  //ISSUE271 diable check field
		    readonlyElement.prop('disabled', true);
	    }else{        
		    readonlyElement.prop('readonly', true);
	    }
            readonlyElement.prop('style', '');

            if ('Detail' === app.getViewName()) {
                readonlyElement.find('.edit').remove();
                readonlyElement.find('.action').remove();
            }
		if(copyElement.length){
                    copyElement.after(readonlyElement);
            }else{
                    fieldElement.after(readonlyElement);

            }
        }

        if (self.isCKEditorField(fieldName)) {
            let data = CKEDITOR.instances[fieldName].getData()

            copyElement.html(data);
            readonlyElement.html(data);
        }
    },
    getReadonlyClass: function (fieldName) {
        return 'fieldname_' + fieldName + '_readonly';
    },
    getReadonlyElement: function (fieldName) {
        return $('.' + this.getReadonlyClass(fieldName));
    },
    showReadonlyElement: function (fieldName) {
        this.getReadonlyElement(fieldName).show();
    },
    removeReadonlyElement: function (fieldName) {
        this.getReadonlyElement(fieldName).remove();
    },
    updateReadonlyCustomElement: function (fieldName, fieldElement, fieldType, show = true) {
        let self = this;

        if (show) {
            self.createReadonlyElement(fieldName, fieldElement);

            if ('date' === fieldType) {
                self.removeDateHandlers(fieldName);
            }

            self.showReadonlyElement(fieldName);
        } else {
            self.removeReadonlyElement(fieldName);
        }
    },
    removeDateHandlers: function (fieldName) {
        const self = this,
            element = self.getReadonlyElement(fieldName);

        element.addClass('dateFieldDisabled');
        element.unbind();
    },
    setReadonlyField: function (fieldName) {
        this.isreadonlyfield.push(fieldName);
    },
    unsetReadonlyField: function (fieldName) {
        const self = this,
            k = jQuery.inArray(fieldName, self.isreadonlyfield);

        if (k > -1) {
            self.isreadonlyfield.splice(k, 1);
        }
    },
    showReferenceButtons: function (tdElement) {
        if (tdElement.find('.sourceField').val()) {
            tdElement.find('.clearReferenceSelection').removeClass('hide');
        }
    },
    hideReferenceButtons: function (tdElement) {
        tdElement.find('.clearReferenceSelection').addClass('hide');
    },
    getFieldElementByName: function (fieldName) {
        let self = this,
            container = self.getContainer(),
            fieldElement;

        if (container) {
            fieldElement = container.find("[name='" + fieldName + "[]']");

            if (!fieldElement.length) {
                fieldElement = container.find("[name='" + fieldName + "']");
            }
        } else {
            fieldElement = jQuery("[name='" + fieldName + "[]']");

            if (!fieldElement.length) {
                fieldElement = jQuery("[name='" + fieldName + "']");
            }
        }

        if (!fieldElement.length) {
            fieldElement = self.getDetailField(fieldName);
        }

        if (!fieldElement.length) {
            fieldElement = self.getSummaryField(fieldName);
        }

        return fieldElement;
    },
    getDetailField: function (fieldName) {
        const self = this;

        return $('#' + self.getDetailFieldId(fieldName));
    },
    getEditField: function (fieldName) {
        const self = this;

        return $('#' + self.getEditFieldId(fieldName));
    },
    getDetailFieldId: function (fieldName) {
        return this.getForModule() + '_detailView_fieldValue_' + fieldName;
    },
    modifyTRLine: function (fieldElement, type) {
        let self = this,
            is_modified = false,
            ClosestTDContent;

        if (fieldElement.length > 0) {
            let ClosestTABLE = fieldElement.closest('table'),
                ClosestTR = fieldElement.closest('tr'),
                ClosestTD = fieldElement.closest('td');

            if (fieldElement.is('td')) {
                ClosestTD = fieldElement;
            }

            if (ClosestTD.is(':hidden')) {
                if ('show' === type) {
                    is_modified = true;
                }
            } else {
                if ('hide' === type) {
                    is_modified = true;
                }
            }

            if ('show' === type) {
                if (ClosestTABLE.is(':hidden')) {
                    ClosestTABLE.show();
                    ClosestTABLE.next("br").show();
                }

                ClosestTD.attr('display', '');
                ClosestTD.css({opacity: 1});
                ClosestTD.show();
            } else {
                if (self.isAddressBlockField(ClosestTD)) {
                    ClosestTD.css({opacity: 0});
                } else {
                    ClosestTD.hide();
                }
            }

            ClosestTDContent = ClosestTD.html();

            for (let c = 0; c < 2; c++) {
                let k = c * 2;
                let TDContent = ClosestTR.find('td').eq((k + 1)).html();

                if (ClosestTDContent === TDContent) {
                    let TDElement = ClosestTR.find('td').eq(k);

                    if ('show' === type) {
                        TDElement.attr('display', '');
                        TDElement.css({opacity: 0.8});
                        TDElement.show();
                    } else {
                        if (self.isAddressBlockField(TDElement)) {
                            TDElement.css({opacity: 0});
                        } else {
                            TDElement.hide();
                        }
                    }
                }
            }
        }

        return is_modified;
    },
    getFieldName: function (element) {
        let name = element.data('fieldname')

        if (!name) {
            name = element.attr('name');
        }

        return name;
    },
    getFieldType: function (element) {
        let type = element.data('fieldtype');

        if (!type) {
            type = element.attr('type');
        }

        return type;
    },
    addValidationToElement: function (elementName, fieldElement, is_mandatory) {
        let self = this,
            is_select2 = false,
            actualize_selectbox = false,
            fieldName = self.getFieldName(fieldElement),
            fieldType = self.getFieldType(fieldElement),
            fieldMandatory = fieldElement.data('rule-required');

        if ('hidden' === fieldType) {
            if (fieldElement.hasClass('sourceField')) {
                let controlElement = fieldElement.closest('td').find("[name='" + fieldName + "_display']");

                if (controlElement.length > 0) {
                    fieldElement = controlElement;
                    fieldType = 'reference';
                }
            }
        }

        if ('file' === fieldType) {
            let ClosestTD = fieldElement.closest('td');
            let uploadedFileNameElement = ClosestTD.find(".uploadedFileName");

            if (uploadedFileNameElement.not(":empty") && is_mandatory) {
                let totalInputElements = uploadedFileNameElement.find("input");

                if (totalInputElements.length > 0) {
                    let inputElements = uploadedFileNameElement.find("input[value='1']");
                    if (inputElements.length > 0) {
                        is_mandatory = false;
                    }
                } else {
                    is_mandatory = false;
                }
            }

            self.control_man_file[fieldName] = !!((fieldMandatory || self.control_man_file[fieldName]) && !is_mandatory);
        } else if ('multipicklist' === fieldType || 'picklist' === fieldType) {
            actualize_selectbox = true;
        }

        if (fieldMandatory !== is_mandatory) {
            fieldElement.data('rule-required', is_mandatory);
            fieldElement.attr('aria-required', is_mandatory);

            if ('reference' === fieldType) {
                fieldElement.data('rule-reference_required', is_mandatory);
            }

             if ('file' === fieldType && is_mandatory) {
                let closestTD = fieldElement.closest('td');
                let uploadedFileNameElement = closestTD.find('.uploadedFileName');

                if (uploadedFileNameElement.children().length) {
                    fieldElement.addClass('ignore-validation');
                }
            }

            if (fieldElement.hasClass("select2")) {
                is_select2 = true;
                actualize_selectbox = true;
            }

            if (actualize_selectbox) {
                if (is_select2) {
                    app.showSelect2ElementView(fieldElement);
                } else {
                    app.destroyChosenElement(fieldElement);
                    app.changeSelectElementView(self.getForm());
                }
            }
        }
    },

    getContainer: function () {
        return this.dfContainer;
    },

    setContainer: function (element) {
        this.dfContainer = element;

        return this;
    },
    setDebugText: function (text) {
        if (window.console && this.debug) console.log('[ITS4YouDynamicFields_PFActions_Js] ', text);
    },
    updateFields: function (load_form, save_form, type) {
        let thisInstance = this;
        let params = load_form.serializeFormData();

        if (thisInstance.isEditView()) {

            for (let fieldName in params) {
                let loadFieldElement = load_form.find("[name='" + fieldName + "']");
                let fieldElement = save_form.find("[name='" + fieldName + "']");

                if (fieldElement.length > 0) {

                    if (fieldElement.is('select')) {
                        let choicesSaveList = fieldElement.find('option');

                        choicesSaveList.each(function (choiceSaveListIndex, saveElement) {
                            let SaveOptionElement = jQuery(saveElement);

                            if (loadFieldElement.find('option[value="' + SaveOptionElement.val() + '"]').is(':selected')) {
                                SaveOptionElement.attr('selected', 'selected');
                            } else {
                                SaveOptionElement.removeAttr('selected');
                            }
                        });
                        fieldElement.trigger('liszt:updated');

                        if (fieldElement.is('.select2')) {
                            app.showSelect2ElementView(fieldElement);
                        } else {
                            app.destroyChosenElement(fieldElement);
                            app.changeSelectElementView(save_form);
                        }

                    } else if ('object' === typeof CKEDITOR.instances[fieldName]) {
                        let fieldValue

                        if ('load' === type) {
                            fieldValue = CKEDITOR.instances[fieldName].getData();

                            params[fieldName] = fieldValue

                            loadFieldElement.text(params[fieldName]);
                        } else {
                            fieldValue = params[fieldName];
                            fieldValue = fieldValue.replaceAll('\r\n', '<br>');
                            fieldValue = fieldValue.replaceAll('\r', '<br>');
                            fieldValue = fieldValue.replaceAll('\n', '<br>');

                            params[fieldName] = fieldValue

                            CKEDITOR.instances[fieldName].setData(params[fieldName]);

                            thisInstance.setFieldVal(fieldName, fieldElement, loadFieldElement, params[fieldName]);
                        }
                    } else {
                        if (fieldElement.length > 1) {
                            fieldElement.each(function (i, obj) {
                                let newFieldElement = jQuery(obj);
                                thisInstance.setFieldVal(fieldName, newFieldElement, loadFieldElement, params[fieldName]);
                            });
                        } else {
                            thisInstance.setFieldVal(fieldName, fieldElement, loadFieldElement, params[fieldName]);
                        }
                    }
                }
            }
        } else {
            if ('save' === type) {
                let postData = {
                    module: thisInstance.forModule,
                    record: thisInstance.forRecord,
                    action: 'SaveAjax'
                };
                postData = jQuery.extend(params, postData);
                app.request.post({data: postData}).then(function (err, data) {

                    if (err === null) {

                        if (!data.error) {
                            jQuery('.vt-notification').remove();
                            app.event.trigger('post.its4you.DF.QuickEditForm.save', data, params);
                            app.helper.hideModal();
                            app.helper.showSuccessNotification({'message': app.vtranslate('JS_RECORD_UPDATED')});
                            window.location.reload();
                        } else {
                            app.helper.showErrorNotification({'message': data.error});
                        }
                    } else {
                        app.event.trigger('post.its4you.DF.QuickEditForm.save', data, params);
                        app.helper.showErrorNotification({'message': err});
                    }
                });
            }
        }
    },
    setFieldVal: function (fieldName, fieldElement, loadFieldElement, newval) {
        let fieldType = fieldElement.data('fieldtype');

        if (typeof fieldType == "undefined") {
            fieldType = fieldElement.attr('type');
        }

        if ('boolean' === fieldType || 'checkbox' === fieldType) {
            if (loadFieldElement.is(':checked')) {
                fieldElement.attr('checked', 'checked');
            } else {
                fieldElement.removeAttr('checked');
            }
        } else {
            fieldElement.val(newval);
        }
    },
    updateSelectFields: function (load_form, save_form) {
        let params = load_form.serializeFormData();

        for (let fieldName in params) {
            let loadFieldElement = load_form.find("[name='" + fieldName + "']");
            let fieldElement = save_form.find("[name='" + fieldName + "']");

            if (fieldElement.length > 0) {

                if (fieldElement.is('select')) {
                    let load_options = loadFieldElement.html();
                    fieldElement.html(load_options);
                } else {
                    fieldElement.val(params[fieldName]);
                }
            }
        }

        return save_form;
    },
    showQuickEditScroll: function () {
        let quickEditScroll = jQuery('.QuickEditScroll');

        if (quickEditScroll.height() > 400) {
            app.showScrollBar(quickEditScroll, {
                height: '400px',
                railVisible: true,
                alwaysVisible: true
            });
        }
    },
    removePopup: function() {
        let modal = $('.myModal');
        modal.before('<div class="modal myModal">');
        modal.remove();
    },
    createPopup: function (new_fields, response, callBackFunction) {
        const self = this;

        self.removePopup();

        if (typeof callBackFunction == 'function') {
            self.cf = callBackFunction;
        } else {
            self.cf = false;
        }

        let postData = {
            module: 'ITS4YouDynamicFields',
            view: 'showFieldsAjax',
            its4you_for_module: self.forModule,
            its4you_for_view: self.forView,
            its4you_for_record: self.forRecord,
            show_fields: JSON.stringify(new_fields),
            showmanfields: JSON.stringify(response['showmanfields']),
            hidemanfields: JSON.stringify(response['hidemanfields']),
        };

        app.helper.showProgress();
        app.request.post({data: postData}).then(
            function (error, result) {
                app.helper.hideProgress();

                if (!error) {
                    let callBackFunction = function (data, save_form) {
                            let form = data.find('.recordEditView');

                            form.submit(function (e) {
                                e.preventDefault();
                            });

                            let params = {
                                submitHandler: function (form) {
                                    let load_form = jQuery(form);

                                    self.updateFields(load_form, save_form, 'save');
                                    app.hideModalWindow();
                                }
                            };
                            form.vtValidate(params);
                            self.showQuickEditScroll();
                        },
                        load_form = self.getForm(),
                        edit_data = self.updateSelectFields(load_form, jQuery(result));

                    app.helper.showModal(edit_data, {
                        'cb': function (modalContainer) {
                            modalContainer.find("a[name='copyAddress']").closest('div').hide();
                            self.updateFields(load_form, modalContainer, 'load');

                            modalContainer.on('click', '.relatedPopup', function (e) {
                                /** @var Vtiger_Edit_Js object */
                                let editViewObj = new Vtiger_Edit_Js();
                                editViewObj.openPopUp(e);
                                return false;
                            });

                            if (typeof callBackFunction == 'function') {
                                callBackFunction(modalContainer, load_form);
                            }
                        }
                    });
                }
            }
        );
    },

    getForm: function () {

        if (this.formElement === false) {
            this.setForm(jQuery('#EditView'));
        }

        return this.formElement;
    },

    setForm: function (element) {
        this.formElement = element;

        return this;
    },

    getLinkKey: function () {
        return jQuery('div.related-tabs').find('li.active').data('link-key');
    },
    registerEvents: function () {
        const self = this;

        self.registerStyles();
        self.registerFixSummaryFields();
        self.registerDetailEdit();

        app.event.on('post.relatedListLoad.click', function (event, searchRow) {
            self.registerStyles();
            self.registerFixSummaryFields();
            self.registerDetailEdit();
        });

        app.event.on('post.overlay.load', function (parentRecordId, params) {
            self.registerDetailEdit();
        });
    },
    registerFixSummaryFields: function () {
        const self = this;

        if (!self.getSummaryFields().length) {
            return;
        }

        self.setForModule(app.getModuleName());
        self.updateSummaryFieldIds();
    },
    getSummaryFields: function() {
        return $('.summaryViewEntries .fieldBasicData');
    },
    updateSummaryFieldIds: function () {
        const self = this;

        self.getSummaryFields().each(function () {
            let element = $(this),
                fieldName = element.data('name'),
                fieldId = self.getSummaryFieldId(fieldName),
                fieldElement = element.parent('.edit').parent('div')

            if (!fieldElement.attr('id')) {
                fieldElement.attr('id', fieldId);
            }
        });
    },
    registerStyles: function () {
        $('body').append('<link type="text/css" rel="stylesheet" href="layouts/v7/modules/ITS4YouDynamicFields/resources/PFActions.css">');
    },
    registerListEdit: function() {
        const self = this,
            actionData = self.actionData,
            fields = actionData.data.fields;

        if(fields) {
            self.setMandatoryFields();
            self.setReadOnlyFields();
            self.setHideFields();
        }
    },
    setHideFields: function() {
        let self = this,
            container = self.getContainer();

        $.each(self.actionData.data.fields.hidefields, function(index, fieldName) {
            container.find('.inputElement[name="' + fieldName + '"]').parents('.edit').addClass('hide');
        });
    },
    setMandatoryFields: function() {
        let self = this,
            container = self.getContainer();

        $.each(self.actionData.data.fields.showmanfields, function(index, fieldName) {
            container.find('.inputElement[name="' + fieldName + '"]').attr('data-rule-required', 'true');
        });
    },
    setReadOnlyFields: function() {
        let self = this,
            container = self.getContainer();

        $.each(self.actionData.data.fields.showreadonlyfields, function(index, fieldName) {
            let fieldElement = container.find('.inputElement[name="' + fieldName + '"]');

            fieldElement.attr('readonly', 'readonly');

            if(fieldElement.is('.sourceField')) {
                let listViewEntryValueElement = fieldElement.parents('.listViewEntryValue');

                listViewEntryValueElement.find('.clearReferenceSelection').remove();
                listViewEntryValueElement.find('.relatedPopup').remove();
            }
        });
    },
    registerDetailEdit: function () {
        app.event.on('PreAjaxSaveEvent', function (e, params) {
            if (!ITS4YouDynamicFields_PFActions_Js.actionData) {
                return true;
            }

            let data = params.triggeredFieldInfo,
                inputElement = $(params.form).find('.inputElement[name="' + data.field + '"]'),
                mandatoryFields = ITS4YouDynamicFields_PFActions_Js.actionData.data.fields.showmanfields;

            if (-1 !== $.inArray(data.field, mandatoryFields) && !data.value) {
                vtUtils.showValidationMessage(inputElement, app.vtranslate('JS_REQUIRED_FIELD'));

                return false;
            }

            return true;
        });

        let detailView = $('#detailView,#headerForm');

        detailView.on('focusout', '.inputElement', function () {
            vtUtils.hideValidationMessage($(this));
        });

        detailView.on('click', '.inlineAjaxCancel', function () {
            vtUtils.hideValidationMessage($(this).parents('.editElement').find('.inputElement'));
        });
    },
});

$(function () {
    ITS4YouDynamicFields_PFActions_Js.getInstance().registerEvents();
});
